AGENTIC SHIKSHA - ARCHITECTURE DIAGRAMS WITH OFFICIAL AZURE ICONS

Updated 2026-09-30.

static-atlas: five architecture views plus an overview, in SVG and PNG.
research: course-creation and platform-topology figures, in SVG and PNG.
motion: six architecture animations, each in SVG, PNG, GIF and MP4.

The downloaded SVGs embed official Microsoft service icons and work without
external image requests. Use the PNGs in documents, GIFs for looping animation,
or MP4s for playback with pause/seek controls. No live deployment is represented.

Original diagram layout is Agentic Shiksha artwork. Microsoft icons remain
subject to the included Microsoft_Terms_of_Use.pdf, not the repository's MIT
license. Do not recolor, crop, rotate, mirror or distort the Microsoft marks, or
use them as your own product branding. Keep service names beside the icons.

Official source: https://learn.microsoft.com/en-us/azure/architecture/icons/
Pack: Azure_Public_Service_Icons_V24.zip

Regeneration sources live in the repository's web/architecture, web/research
and web/motion folders. This download contains finished architecture assets,
not application code, real learner data, credentials or tutorial recordings.
